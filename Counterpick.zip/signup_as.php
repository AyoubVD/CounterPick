<?php include_once "./components/header.php" ?>
            <br>
            <br>
            <a style="color: white;padding: 14px 25px;text-decoration: none;display: inline-block;background-color: #000000;background-image: linear-gradient(315deg, #000000 0%, #414141 74%);" href="./create_team/signup_team.php">Create Team</a>
            <br>
            <br>
            <a style="color: white;padding: 14px 25px;text-decoration: none;display: inline-block;background-color: #000000;background-image: linear-gradient(315deg, #000000 0%, #414141 74%);" href="signup.php">Create Player</a>
            <br>
            <br>       
<?php include_once "./components/footer.php" ?>
</body>
</html>