<?php include_once "./components/header.php" ?>
<div class="contain" style = "display: flex;
                        flex-wrap: wrap;
                        align-items: center;
                        border: 1px solid rgba(23,23,23, .2);
                        margin: 5px;
                        padding: 5px;
                        width: 20%;
                        background-color: #FFF;
                        align-items: stretch;
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center;
                        text-align: center;
                        align-content: center;
                        margin-left: auto;
                        margin-right: auto;
                        background-image: url(https://lolstatic-a.akamaihd.net/frontpage/apps/prod/clash-2018/en_GB/a46e742ae82f9d4f9db8e34ba57873e513e727b7/assets/static/img/backgrounds/brackets-bg.jpg);color:white;">
        <h1>Intro</h1>
        <p>
            Counterpick is an web application for everyone that is interested in playing League of Legends (LoL) at amateur level.<br>
            It will consist of teams of 5 players with relatively the same skillset. So you won’t be bullied by players with a much higher ranking.<br>
            All you would need is the LoL application, our web application and a stable network connection.<br>
            Register or log in now to start playing!<br>
        </p> 
        <h1>Can't wait?</h1>
        <h2>Do not smurf please!</h2>
        <h2>This is for beginners and for players from unranked to silver!</h2>
        <h1><a style="color: #EB1E36;" href='login_as.php' padding-left="2%">Login here!</a></h1>
        <h1><a style="color: #EB1E36;" href='signup_as.php'>Register here!</a></h1>
        <br>
        <footer style="color:white;">
    <a style="color:white;" href="https://counterpick123.wordpress.com/">About us</a>
    <a style="color:white;" href="https://www.youtube.com/watch?v=gYRsfboeAnM">Teaser</a>
    <br>
    © 2021 - Counterpick - Thomas More
</footer>
        </div>
 
</body>
</html>
