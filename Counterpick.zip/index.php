<?php include_once "./components/header.php" ?>
<h1 style = "display: flex;
                        flex-wrap: wrap;
                        align-items: center;
                        border: 1px solid rgba(23,23,23, .2);
                        margin: 5px;
                        padding: 5px;
                        width: 20%;
                        background-color: #FFF;
                        align-items: stretch;
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center;
                        text-align: center;
                        align-content: center;
                        margin-left: auto;
                        margin-right: auto;
                        background-image: url('https://lolstatic-a.akamaihd.net/frontpage/apps/prod/clash-2018/en_GB/a46e742ae82f9d4f9db8e34ba57873e513e727b7/assets/static/img/backgrounds/brackets-bg.jpg');
                        color:white;" >Welkom bij Counterpick!</h1>
<br>
<br>
<br>
        <div id="content" style = "display: flex;
                        flex-wrap: wrap;
                        align-items: center;
                        border: 1px solid rgba(23,23,23, .2);
                        margin: 5px;
                        padding: 5px;
                        width: 20%;
                        background-color: #FFF;
                        align-items: stretch;
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center;
                        text-align: center;
                        align-content: center;
                        margin-left: auto;
                        margin-right: auto;
                        background-image: url('https://lolstatic-a.akamaihd.net/frontpage/apps/prod/clash-2018/en_GB/a46e742ae82f9d4f9db8e34ba57873e513e727b7/assets/static/img/backgrounds/brackets-bg.jpg');
                        color:white;">
            
            <h2>What is CounterPick?</h2>
            <h2>Here is our teaser!</h2>
            <br>
            <iframe width="420" height="315" 
                src="https://www.youtube.com/embed/gYRsfboeAnM">
            </iframe>
            <br>
            <h3>CounterPick is <u>four</u> points</h3>
            <br>
            <p>To help and guide anyone who wants to play competitively at the amateur level.</p>
            <br>
            <p>For everybody who plays competitively comp LOL and is an amateur.</p>
            <br>
            <p>A web application where you can find data on the current state of the tournament.</p>
            <br>
            <p>We are using an python script to get the necessary information on the players and using it to match the players on the same skillset.</p>
            <br>
            <h3>
            So you might ask, isn't this a lot. <br>
            For us it is, but for the players it isn't. <br>
            We will list <b>all</b> the requirements below.
            </h3>
            <br>
            <p>LOL installed, updated web browser and a stable network connection</p>      
            <p>As you can see this isn't a lot, so what's holding you back? <br>
            Come and join the community to become a better League player!</p>
            <footer style="color:white;">
    <a style="color:white;" href="https://counterpick123.wordpress.com/">About us</a>
    <a style="color:white;" href="https://www.youtube.com/watch?v=gYRsfboeAnM">Teaser</a>
    <br>
    © 2021 - Counterpick - Thomas More
</footer>
</body>
</html>



