<?php include_once "./components/header.php" ?>
<link rel="stylesheet" type="text/css" href="./css/index.css">
                <h1>log in as</h1>
            <br>
            <br>
            <a style="color: white;padding: 14px 25px;text-decoration: none;display: inline-block;background-color: #000000;background-image: linear-gradient(315deg, #000000 0%, #414141 74%);" href="./create_team/login_team.php">Team</a>
            <br>
            <br>
            <a style="color: white;padding: 14px 25px;text-decoration: none;display: inline-block;background-color: #000000;background-image: linear-gradient(315deg, #000000 0%, #414141 74%);" href="login.php">Player</a>
            <br>
            <br>
    <?php include_once "./components/footer.php" ?>
</body>
</html>