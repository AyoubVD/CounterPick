<footer>
    <a href="https://counterpick123.wordpress.com/">About us</a>
    <a href="https://www.youtube.com/watch?v=gYRsfboeAnM">Teaser</a>
    <br>
    © 2021 - Counterpick - Thomas More
</footer>
           
          
           
          